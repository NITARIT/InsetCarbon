# InsetCarbon — Startup Instructions

Follow this guide to get the development server up and running on your local machine or hosting environment quickly.

---

## 📋 Prerequisites

Before starting, ensure you have the following installed on your machine:
* **Node.js**: Version 18.x, 20.x, or 22.x (Recommended: Node.js 22.x LTS)
* **npm**: Version 10.x or later (comes pre-bundled with Node.js)

---

## ⚡ Step-By-Step Setup

### Step 1: Install Dependencies
Open your favorite terminal, navigate to the project root directory, and run:
```bash
npm install
```
This downloads and resolves all required dependency packages (including React 19, Tailwind v4, Framer Motion, and Lucide React).

### Step 2: Configure Environment Variables
Copy `.env.example` into a new `.env` file:
```bash
cp .env.example .env
```
*(Optional: If you intend to connect any Gemini AI workflows, append your user secret under `GEMINI_API_KEY="..."` inside `.env`).*

### Step 3: Launch Local Development Server
Execute the dev command:
```bash
npm run dev
```
Upon success, the terminal will display the active URL:
```text
  VITE v6.2.3  ready in 420 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: http://192.168.1.10:3000/
```
Open `http://localhost:3000/` in your web browser to view the application live!

---

## 🔧 Production Build & Deployment

To build a fully production-ready, highly optimized, and compressed static version of the site:
```bash
npm run build
```
This bundles the compiled assets inside `/dist`. Any static file server (such as Vercel, Netlify, AWS S3, or Nginx) can serve this `/dist` directory directly.

---

## 🛠️ Troubleshooting & Support

### Issue 1: Port 3000 is already in use
If another application is running on port 3000, copy the command with a customized port, or kill the process on port 3000:
* **Customize Port**: Make an alias edit or run:
  ```bash
  npx vite --port=3001
  ```
* **Kill Port Process (macOS/Linux)**:
  ```bash
  kill -9 $(lsof -t -i:3000)
  ```

### Issue 2: TypeScript typeerrors or JSX errors
Ensure your editor is using the workspace version of TypeScript (v5.x). You can check compilation typing at any time by running:
```bash
npm run lint
```
This invokes `tsc --noEmit` and reports any strict compilation anomalies safely.
