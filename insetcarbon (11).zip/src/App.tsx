import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import ProblemSection from "./components/ProblemSection";
import ScienceSection from "./components/ScienceSection";
import CoBenefitsSection from "./components/CoBenefitsSection";
import OperationsSection from "./components/OperationsSection";
import MRVSection from "./components/MRVSection";
import TeamSection from "./components/TeamSection";
import CorporatesSection from "./components/CorporatesSection";
import ContactSection from "./components/ContactSection";
import FooterSection from "./components/FooterSection";

export default function App() {
  return (
    <div className="font-sans text-forest bg-site-bg min-h-screen selection:bg-brand/30 selection:text-forest">
      <Navbar />
      <main>
        <HeroSection />
        <ProblemSection />
        <ScienceSection />
        <CoBenefitsSection />
        <OperationsSection />
        <MRVSection />
        <TeamSection />
        <CorporatesSection />
        <ContactSection />
      </main>
      <FooterSection />
    </div>
  );
}
