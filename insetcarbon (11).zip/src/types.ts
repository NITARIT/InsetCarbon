import { ComponentType, ReactNode } from "react";

export interface NavigationItem {
  label: string;
  href: string;
}

export interface FeatureItem {
  icon: ComponentType<{ className?: string }>;
  label: string;
}

export interface ProblemStat {
  value: string;
  label: string;
  sub: string;
}

export interface WeatheringStep {
  num: string;
  icon: ComponentType<{ className?: string }> | (() => ReactNode);
  label: string;
  formula: string;
  desc: string;
  accent: string;
  ring: string;
  bg: string;
  iconCls: string;
}

export interface CoBenefitItem {
  icon: ComponentType<{ className?: string }>;
  label: string;
  desc: string;
  color: string;
}

export interface StateSuitability {
  id: string;
  name: string;
  cx: number;
  cy: number;
  rx: number;
  ry: number;
  rotate?: number;
  tier: "active" | "high" | "moderate" | "emerging";
  basalt: string;
  agriculture: string;
  carbon: string;
  logistics: string;
  note?: string;
  climate?: string;
  status?: string;
}

export interface MRVStep {
  icon: ComponentType<{ className?: string }>;
  title: string;
  body: string;
}

export interface FeatureCard {
  icon: ComponentType<{ className?: string }>;
  title: string;
  desc: string;
  metrics: string[];
  accent: string;
}

export interface CorporateStep {
  n: string;
  t: string;
  d: string;
}
