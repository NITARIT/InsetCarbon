import { motion } from "motion/react";

const MEDIA_URLS = {
  video: "https://drive.google.com/file/d/13AjPuvpPB2k-hLv2MjHB73ILp07uC364/preview",
  baselines: "https://drive.google.com/thumbnail?id=1CORqszN6Noan_NNMWNk8DvZgT5cnBNXl&sz=w1600",
  feedstock: "https://drive.google.com/thumbnail?id=1aJVTsvjVbW7p-x4G34VOG52dOnqc5ZwK&sz=w1600",
  soil: "https://drive.google.com/thumbnail?id=1IPeuyQUvr6xUYAs1hSeEwDSaKTMKi7dU&sz=w1600",
  executing: "https://drive.google.com/thumbnail?id=14kp4EVq4tQ_qzgR2x0H2K0HcvH-cXIlC&sz=w1600",
};

interface OperationCardProps {
  title: string;
  description: string;
  src: string;
  badge?: string;
  index: number;
  key?: string;
  imageClassName?: string;
  className?: string;
}

function OperationCard({ title, description, src, badge, index, imageClassName = "", className = "" }: OperationCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className={`relative rounded-2xl overflow-hidden group shadow-md border border-forest/10 bg-slate-950 cursor-pointer ${className}`}
    >
      <img
        src={src}
        alt={title}
        loading="lazy"
        decoding="async"
        className={`absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105 ${imageClassName}`}
        referrerPolicy="no-referrer"
      />
      {/* Soft overlay gradient that handles readability for white text */}
      <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-black/90 via-black/45 to-transparent pointer-events-none z-10" />
      
      {/* Top action badge if present */}
      {badge && (
        <div className="absolute top-4 left-4 z-20">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 border border-white/10 backdrop-blur-sm text-[10px] font-mono font-medium text-white tracking-wider uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse" />
            {badge}
          </span>
        </div>
      )}

      {/* Narrative content block */}
      <div className="absolute bottom-0 inset-x-0 p-5 md:p-6 z-20 flex flex-col justify-end">
        <h3 className="text-base md:text-lg font-semibold text-white leading-tight mb-1">
          {title}
        </h3>
        <p className="text-xs text-white/80 line-clamp-2 font-light leading-relaxed max-w-[95%]">
          {description}
        </p>
      </div>
    </motion.div>
  );
}

export default function OperationsSection() {
  interface OpItem {
    title: string;
    description: string;
    src: string;
    badge?: string;
    imageClassName?: string;
    className?: string;
  }

  const operations: OpItem[] = [
    {
      title: "Precision Application",
      badge: "Active Deployment",
      src: "/src/assets/images/rice_paddies_application_1779524790464.png",
      description: "Accurate mechanical basalt mineral distribution across water-filled green rice paddy environments.",
      className: "h-[280px] md:h-[320px] lg:h-[320px] w-full",
    },
    {
      title: "Agricultural Baselines",
      src: MEDIA_URLS.baselines,
      description: "Rigorous pre-treatment soil grid profiling to verify carbon enrichment models securely.",
      className: "h-[280px] md:h-[320px] lg:h-[320px] w-full",
      imageClassName: "contrast-[1.12] brightness-[0.92] saturate-[1.08]",
    },
    {
      title: "Feedstock Sourcing",
      src: MEDIA_URLS.feedstock,
      description: "Sourcing pure natural volcanic rock nutrients to optimize high quality mineral spread.",
      className: "h-[280px] md:h-[320px] lg:h-[320px] w-full",
      imageClassName: "contrast-[1.12] brightness-[0.92] saturate-[1.12]",
    },
    {
      title: "Soil Preparation",
      src: MEDIA_URLS.soil,
      description: "Conditioning fields and measuring regional soil parameters prior to mineral placement.",
      className: "h-[280px] md:h-[320px] lg:h-[320px] w-full",
      imageClassName: "contrast-[1.12] brightness-[0.92] saturate-[1.08]",
    },
    {
      title: "Executing at Scale",
      src: MEDIA_URLS.executing,
      description: "Rapid basalt rock dust loading of dumper trucks and tractor trolleys across complex Indian farm terrain.",
      className: "h-[280px] md:h-[320px] lg:h-[320px] w-full md:col-span-2 lg:col-span-2",
      imageClassName: "contrast-[1.12] brightness-[0.92] saturate-[1.05]",
    },
  ];

  return (
    <section className="py-20 md:py-28 bg-white text-forest" id="operations row-gap-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12 md:mb-16">
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-3 font-semibold">
            On The Ground
          </p>
          <h2 className="text-3xl md:text-5xl font-semibold leading-tight mb-5">
            Ground truth, not desk research
          </h2>
          <p className="text-base md:text-lg text-forest/65 font-light leading-relaxed">
            We operate strictly in the physical world. Our teams build real agricultural baselines, coordinate local feedstock sourcing, and measure actual soil change on-site. No estimates, no armchair science.
          </p>
        </div>

        {/* CSS Grid for structured, uniform layout alignment */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {operations.map((op, index) => (
            <OperationCard
              key={op.title}
              title={op.title}
              description={op.description}
              src={op.src}
              badge={op.badge}
              index={index}
              imageClassName={op.imageClassName}
              className={op.className}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
