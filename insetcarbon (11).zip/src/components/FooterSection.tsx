import { motion } from "motion/react";
import { ArrowRight, Mail, Linkedin } from "lucide-react";
import Logo from "./Logo";

export default function FooterSection() {
  return (
    <>
      {/* CTA Section */}
      <section
        className="relative py-28 md:py-36 bg-[#1A3C2B] text-white text-center overflow-hidden"
        id="cta-section"
      >
        {/* Soft atmospheric background reflection of the quarry/basalt scene */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none opacity-[0.95]">
          <img
            src="https://drive.google.com/thumbnail?id=1IHIvB3GA19aTiii1Gz5fzlW9g2vELn9C&sz=w1600"
            alt="Basalt feedstock source reflection background"
            loading="lazy"
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
            style={{
              filter: "blur(1px) saturate(1.45) contrast(1.1) brightness(0.70)",
            }}
          />
          {/* Reduced green cast: Using a lighter dark neutral overlay to allow details to shine through */}
          <div className="absolute inset-0 bg-[#0c140e]/15 mix-blend-multiply" />
          <div 
            className="absolute inset-0"
            style={{
              background: "radial-gradient(circle at 50% 50%, transparent 25%, rgba(13, 26, 18, 0.65) 90%)"
            }}
          />
        </div>

        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-brand/40 to-transparent z-10" />
        <motion.div
          animate={{ opacity: [0.08, 0.18, 0.08], scale: [1, 1.08, 1] }}
          transition={{
            repeat: Infinity,
            duration: 10,
            ease: "easeInOut",
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-brand/15 blur-[120px] rounded-full pointer-events-none z-10"
        />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
          <p className="text-xs sm:text-sm font-mono text-brand/70 uppercase tracking-[0.22em] mb-6 font-semibold">
            Ready to act?
          </p>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-semibold tracking-tight leading-[1.08] mb-7 max-w-3xl mx-auto">
            Turn your supply chain into a permanent carbon sink.
          </h2>
          <p className="text-lg text-white/60 mb-11 font-light max-w-xl mx-auto leading-relaxed">
            Design a science-backed insetting programme aligned to your
            procurement geography.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3">
            <a href="mailto:contact@insetcarbon.com" id="cta-design-btn">
              <button
                className="bg-[#3de3a6] text-[#07130d] px-8 py-4 rounded-full font-semibold inline-flex items-center gap-2 hover:bg-[#5affc4] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 shadow-[0_4px_24px_rgba(61,227,166,0.25)]"
                id="cta-design-btn-inner"
              >
                Design your programme <ArrowRight className="w-4 h-4 text-[#07130d]" />
              </button>
            </a>
            <a href="mailto:contact@insetcarbon.com" id="cta-feasibility-btn">
              <button
                className="bg-[#3de3a6]/8 text-[#3de3a6] px-8 py-4 rounded-full font-medium border border-[#3de3a6]/25 hover:bg-[#3de3a6]/15 hover:border-[#3de3a6]/40 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300"
                id="cta-feasibility-btn-inner"
              >
                Book a feasibility call
              </button>
            </a>
          </div>
        </div>
      </section>

      {/* Footer Area */}
      <footer
        className="bg-[#070f09] text-white/40 py-10 border-t border-white/5"
        id="app-footer"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <Logo variant="dark" heightClass="h-5 md:h-6" />

          <div className="flex flex-wrap items-center gap-6 text-sm">
            <a
              href="mailto:contact@insetcarbon.com"
              className="hover:text-white transition-colors flex items-center gap-1.5"
              id="footer-email-link"
            >
              <Mail className="w-3.5 h-3.5" /> contact@insetcarbon.com
            </a>
            <a
              href="https://www.linkedin.com/company/insetcarbon/"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
               id="footer-linkedin-link"
            >
              <Linkedin className="w-4 h-4" style={{ fill: "currentColor" }} />
            </a>
          </div>

          <p className="text-xs font-mono">
            © {new Date().getFullYear()} InsetCarbon. All rights reserved.
          </p>
        </div>
      </footer>
    </>
  );
}
