import { motion } from "motion/react";
import { Mail, Linkedin } from "lucide-react";

export default function ContactSection() {
  return (
    <section
      id="contact"
      className="py-24 md:py-32 bg-[#0a120e] text-white relative overflow-hidden"
    >
      {/* Cinematic, luxury Apple-style soft reflection element with a faint recognizable silhouette */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none opacity-[0.98]">
        <img
          src="https://drive.google.com/thumbnail?id=1-vsCPVYfe0RdfYaUQpOmCSYvXDEyrbQh&sz=w1600"
          alt="Atmospheric landscape reflections behind contact section"
          loading="lazy"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
          style={{
            filter: "blur(0.5px) saturate(1.4) brightness(0.85) contrast(1.12)",
            objectPosition: "50% 60%",
          }}
        />
        {/* Soft, rich emerald and dark green overlays to blend the reflection seamlessly into the website's canvas */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a120e] via-transparent to-[#0a120e]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a120e] via-transparent to-[#0a120e]" />
        <div 
          className="absolute inset-0 bg-[#0a120e] mix-blend-multiply opacity-[0.15]"
        />
        <div 
          className="absolute inset-0 mix-blend-color-burn opacity-35"
          style={{
            background: "radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.15) 0%, transparent 80%)"
          }}
        />
      </div>

      {/* Radiant premium ambient bloom lights */}
      <div className="absolute top-1/4 left-1/3 -translate-x-1/2 w-[600px] h-[600px] bg-[#10b981]/8 rounded-full blur-[140px] pointer-events-none mix-blend-screen opacity-70 z-0" />
      <div className="absolute bottom-1/4 right-0 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[130px] pointer-events-none mix-blend-screen opacity-40 z-0" />

      {/* No background grid pattern */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-8 items-stretch">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col justify-between gap-8 animate-fadeIn"
          >
            <div>
              <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-5 font-semibold">
                Contact
              </p>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight leading-[1.1] mb-6">
                Let's build your carbon insetting programme.
              </h2>
              <p className="text-base text-white/50 font-light leading-relaxed max-w-lg">
                Reach out to discuss Scope 3 strategy, ERW pilots, MRV
                collaboration, or supply chain mapping. We respond within 48
                hours.
              </p>
            </div>
            <div>
              <a
                href="mailto:contact@insetcarbon.com"
                className="inline-flex items-center gap-3 text-white font-medium hover:text-brand transition-colors group text-base"
                id="contact-email-link"
              >
                <div className="w-10 h-10 rounded-full bg-white/6 border border-white/10 flex items-center justify-center group-hover:bg-brand/15 group-hover:border-brand/30 transition-colors">
                  <Mail className="w-4 h-4" />
                </div>
                contact@insetcarbon.com
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.08 }}
            className="bg-white/4 border border-white/8 rounded-3xl p-9 relative overflow-hidden"
            id="contact-info-card"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-brand/8 blur-3xl rounded-full pointer-events-none" />
            <div className="relative z-10 flex flex-col h-full justify-between gap-8">
              <div>
                <h4 className="text-xl font-semibold mb-1">Saurabh Kumar</h4>
                <p className="text-white/40 font-mono text-[11px] uppercase tracking-wider mb-7">
                  Co-Founder, InsetCarbon
                </p>
                <blockquote className="text-white/65 font-light leading-relaxed text-sm md:text-base italic border-l-2 border-brand/40 pl-4">
                  &ldquo;Our goal is to give companies the operational
                  capability to remove carbon directly from the agricultural
                  lands they depend on, creating enduring value for both the
                  climate and the farmer.&rdquo;
                </blockquote>
              </div>
              <div className="flex flex-wrap items-center gap-4 pt-7 border-t border-white/8">
                <a
                  href="mailto:saurabh@insetcarbon.com"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#3de3a6] bg-transparent border border-[#3de3a6]/30 px-6 py-2.5 rounded-full hover:bg-[#3de3a6]/10 hover:border-[#3de3a6]/60 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300"
                  id="contact-founder-email"
                >
                  <Mail className="w-4 h-4 text-[#3de3a6]" /> Email Us!
                </a>
                <a
                  href="https://www.linkedin.com/company/insetcarbon/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white/40 hover:text-white transition-colors"
                  id="contact-founder-linkedin"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
