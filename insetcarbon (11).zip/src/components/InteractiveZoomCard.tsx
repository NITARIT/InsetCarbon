import { motion, useMotionValue, useSpring, useTransform, HTMLMotionProps } from "motion/react";
import React, { useRef, useState, useEffect } from "react";

interface InteractiveZoomCardProps extends HTMLMotionProps<"div"> {
  children: React.ReactNode;
  glowColor?: string;
}

export default function InteractiveZoomCard({
  children,
  className = "",
  glowColor = "rgba(29,158,117,0.14)", // subtle premium green brand glow by default
  id,
  style = {},
  ...props
}: InteractiveZoomCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isMobile, setIsMobile] = useState(false);

  // Check if we are on a touch device
  useEffect(() => {
    const checkViewport = () => {
      setIsMobile(window.matchMedia("(max-width: 768px)").matches);
    };
    checkViewport();
    window.addEventListener("resize", checkViewport);
    return () => window.removeEventListener("resize", checkViewport);
  }, []);

  // Motion values
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const glowX = useMotionValue(0);
  const glowY = useMotionValue(0);
  const glowOpacity = useMotionValue(0);

  // Extremely smooth spring configurations
  const springConfig = { damping: 25, stiffness: 140, mass: 0.8 };
  
  // Use transforms and spring for ultra-smooth 60fps translations (reduced tilt on mobile to preserve scrolling layout)
  const tiltXValue = useTransform(y, [-0.5, 0.5], isMobile ? [0, 0] : [7, -7]);
  const tiltYValue = useTransform(x, [-0.5, 0.5], isMobile ? [0, 0] : [-7, 7]);
  
  const rotateX = useSpring(tiltXValue, springConfig);
  const rotateY = useSpring(tiltYValue, springConfig);
  
  const scaleValue = useMotionValue(1);
  const scale = useSpring(scaleValue, { damping: 22, stiffness: 160 });
  
  const springGlowX = useSpring(glowX, { damping: 30, stiffness: 180 });
  const springGlowY = useSpring(glowY, { damping: 30, stiffness: 180 });
  const springGlowOpacity = useSpring(glowOpacity, { damping: 25, stiffness: 160 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current || isMobile) return;
    const rect = cardRef.current.getBoundingClientRect();
    
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Map mouse position coordinates between -0.5 and 0.5
    x.set((mouseX / width) - 0.5);
    y.set((mouseY / height) - 0.5);

    // Map glow target coordinates
    glowX.set(mouseX);
    glowY.set(mouseY);
  };

  const handleMouseEnter = () => {
    if (isMobile) return;
    scaleValue.set(1.04);
    glowOpacity.set(1);
  };

  const handleMouseLeave = () => {
    scaleValue.set(1);
    x.set(0);
    y.set(0);
    glowOpacity.set(0);
  };

  // Convert animated mouse tracking coordinates to a radial gradient style string
  const radialGlow = useTransform(
    [springGlowX, springGlowY],
    ([gx, gy]) => {
      return `radial-gradient(350px circle at ${gx}px ${gy}px, ${glowColor}, transparent 80%)`;
    }
  );

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      id={id}
      style={{
        transformStyle: "preserve-3d",
        rotateX,
        rotateY,
        scale,
        ...style,
      }}
      className={`relative overflow-hidden transition-shadow duration-300 ${
        isMobile ? "" : "hover:shadow-[0_16px_40px_rgba(26,60,43,0.12)]"
      } ${className}`}
      {...props}
    >
      {/* Premium Apple/Stripe-styled Radial Light Glow */}
      {!isMobile && (
        <motion.div
          className="absolute inset-0 pointer-events-none z-10"
          style={{
            background: radialGlow,
            opacity: springGlowOpacity,
          }}
        />
      )}
      
      {/* Content wrapper with slight translateZ for 3D depth */}
      <div 
        style={{ transform: !isMobile ? "translateZ(12px)" : "none" }} 
        className="relative z-20 h-full w-full"
      >
        {children}
      </div>
    </motion.div>
  );
}
