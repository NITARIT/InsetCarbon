import { motion } from "motion/react";
import { Check, ArrowRight } from "lucide-react";
import { CorporateStep } from "../types";
import InteractiveZoomCard from "./InteractiveZoomCard";

const CORPORATE_STEPS: CorporateStep[] = [
  {
    n: "01",
    t: "Supply chain mapping",
    d: "We identify your agricultural sourcing regions and ERW deployment opportunity.",
  },
  {
    n: "02",
    t: "Pilot design & cost modeling",
    d: "Custom removal estimates, cost per tonne projections, and pilot scope defined.",
  },
  {
    n: "03",
    t: "Field deployment",
    d: "Agronomy team deploys basalt at contracted farms with full MRV documentation.",
  },
  {
    n: "04",
    t: "Verification & reporting",
    d: "Isometric-verified removal credits with farmer impact reporting for your ESG disclosures.",
  },
];

const FITMENT_CRITERIA = [
  "Agricultural sourcing network in India",
  "Scope 3 decarbonization goals",
  "Interest in durable carbon removal",
  "Direct farmer engagement and impact",
];

export default function CorporatesSection() {
  return (
    <section className="py-24 md:py-32 bg-site-bg" id="corporates">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-4 font-semibold">
            For Corporates
          </p>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-forest tracking-tight leading-[1.1] mb-5">
            Built for enterprise Scope 3 decarbonization.
          </h2>
          <p className="text-base text-muted font-light leading-relaxed">
            We work directly with sustainability teams to design programmes that
            match your specific supply chain geography, budget, and reporting
            requirements.
          </p>
        </motion.div>

        {/* 4 Step Cards with Interactive Zoom/Glow */}
        <div className="grid md:grid-cols-4 gap-4 mb-12">
          {CORPORATE_STEPS.map((step, idx) => (
            <InteractiveZoomCard
              key={step.n}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.08 }}
              className="bg-white rounded-2xl p-7 border border-forest/6 relative"
              glowColor="rgba(29, 158, 117, 0.09)"
            >
              <span className="text-3xl font-bold text-forest/8 font-mono absolute top-5 right-6 select-none z-10">
                {step.n}
              </span>
              <h4 className="text-sm font-semibold text-forest mb-2 pr-8 leading-snug relative z-20">
                {step.t}
              </h4>
              <p className="text-xs text-muted leading-relaxed relative z-20">{step.d}</p>
            </InteractiveZoomCard>
          ))}
        </div>

        {/* Suitability and Call-To-Action double block */}
        <div className="grid md:grid-cols-2 gap-5">
          <InteractiveZoomCard
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-[#1A3C2B] rounded-3xl p-9 flex flex-col justify-center min-h-[300px]"
            glowColor="rgba(29, 158, 117, 0.18)"
          >
            <h3 className="text-base font-semibold text-white mb-5">
              You're a good fit if you have:
            </h3>
            <ul className="space-y-3">
              {FITMENT_CRITERIA.map((criterion) => (
                <li
                  key={criterion}
                  className="flex items-start gap-3 text-sm text-white/70"
                >
                  <div className="w-5 h-5 rounded-full bg-brand/20 border border-brand/30 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3 text-brand" strokeWidth={3} />
                  </div>
                  {criterion}
                </li>
              ))}
            </ul>
          </InteractiveZoomCard>

          <InteractiveZoomCard
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.08 }}
            className="bg-brand rounded-3xl p-9 flex flex-col justify-between min-h-[300px]"
            glowColor="rgba(255, 255, 255, 0.22)"
          >
            <div>
              <h3 className="text-xl md:text-2xl font-semibold text-white mb-4 leading-snug">
                Ready to design your insetting programme?
              </h3>
              <p className="text-white/75 text-sm leading-relaxed mb-8">
                Book a no-commitment feasibility call. We'll map your supply
                chain, estimate removal potential, and outline a pilot scope
                within 2 weeks.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="mailto:contact@insetcarbon.com"
                id="footer-feasibility-btn"
              >
                <button
                  className="bg-white text-forest px-6 py-3 rounded-full text-sm font-semibold hover:bg-white/90 transition-colors inline-flex items-center gap-2"
                  id="footer-feasibility-btn-inner"
                >
                  Book a feasibility call <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </a>
            </div>
          </InteractiveZoomCard>
        </div>
      </div>
    </section>
  );
}
export { CORPORATE_STEPS, FITMENT_CRITERIA };
