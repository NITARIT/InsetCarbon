import { motion } from "motion/react";
import { ArrowRight, HeartPulse, FlaskConical, MapPin } from "lucide-react";
import { FeatureItem } from "../types";
// @ts-ignore
import farmlandHero from "../assets/images/farmland_hero_1779520864870.png";

const HERO_FEATURES: FeatureItem[] = [
  { icon: HeartPulse, label: "Scope 3 Starts on Farms" },
  { icon: FlaskConical, label: "Science-Backed · IIT-Linked Ecosystem" },
  { icon: MapPin, label: "Field-Validated ERW Deployment" },
];

const HERO_STATS = [
  { value: "4+", label: "Years of Ground-Tested Climate-Tech Innovation" },
  { value: "Isometric", label: "latest MRV standard" },
  { value: "Jharkhand · WB", label: "Active regions" },
];

export default function HeroSection() {
  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden bg-[#060c08]"
      id="hero-section"
    >
      <div className="absolute inset-0 z-0 select-none overflow-hidden">
        {/* The Base Cinematic Crop of the Farm Image */}
        <img
          src={farmlandHero}
          alt="Lush agricultural farming in India"
          loading="eager"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none"
          style={{
            objectPosition: "50% 32%",
            filter: "brightness(0.42) contrast(1.18) saturate(1.05)",
          }}
        />



        {/* 1. Fog / Haze Ambient Layer (Gives that cinematic soft fog/haze rising from the field) */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-[0.25]"
          style={{
            background: "linear-gradient(to top, rgba(6, 12, 8, 0.95) 0%, rgba(29, 158, 117, 0.08) 35%, rgba(20, 184, 166, 0.04) 70%, rgba(6, 12, 8, 0.2) 100%)"
          }}
        />

        {/* 2. Global Dark Vignette & Edge Feather Overlay */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "radial-gradient(circle at 50% 40%, transparent 15%, rgba(6, 12, 8, 0.5) 45%, rgba(6, 12, 8, 0.96) 85%, #060c08 100%)"
          }}
        />

        {/* 3. Top Edge Fade: Fades cleanly from solid black background */}
        <div 
          className="absolute inset-x-0 top-0 h-48 pointer-events-none"
          style={{
            background: "linear-gradient(to bottom, #060c08 0%, rgba(6, 12, 8, 0.8) 35%, transparent 100%)"
          }}
        />

        {/* 4. Bottom Edge Fade: Seamless scroll integration */}
        <div 
          className="absolute inset-x-0 bottom-0 h-56 pointer-events-none"
          style={{
            background: "linear-gradient(to top, #060c08 0%, rgba(6, 12, 8, 0.62) 40%, transparent 100%)"
          }}
        />

        {/* 5. Left Sidebar Protective Overlay (Protects readability of typography) */}
        <div 
          className="absolute inset-y-0 left-0 w-full md:w-2/3 pointer-events-none"
          style={{
            background: "linear-gradient(to right, #060c08 0%, rgba(6, 12, 8, 0.94) 30%, rgba(6, 12, 8, 0.8) 55%, rgba(6, 12, 8, 0.25) 80%, transparent 100%)"
          }}
        />

        {/* 6. Realistic Ambient Emerald / Teal Bloom & Glow Behind Headline */}
        <div 
          className="absolute top-[45%] left-[30%] -translate-x-1/2 -translate-y-1/2 w-[750px] h-[550px] rounded-full bg-gradient-to-tr from-brand/12 via-teal-500/6 to-emerald-500/3 blur-[140px] mix-blend-screen pointer-events-none opacity-90" 
        />
        <div 
          className="absolute top-[35%] left-[20%] -translate-x-1/2 -translate-y-1/2 w-[500px] h-[400px] rounded-full bg-brand/[0.08] blur-[110px] mix-blend-color-dodge pointer-events-none" 
        />
      </div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 pt-24 pb-20">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/18 bg-white/5 backdrop-blur-md text-white/75 text-xs sm:text-sm font-mono uppercase tracking-[0.18em] mb-8 font-semibold"
            id="hero-badge"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-brand animate-pulse" />
            Enhanced Rock Weathering · India
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, delay: 0.2 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-[4.5rem] font-semibold text-white tracking-tight leading-[1.06] mb-7"
            id="hero-heading"
          >
            Remove carbon from
            <br className="hidden sm:block" />
            <span className="text-brand"> within your supply chain.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.32 }}
            className="text-base md:text-lg lg:text-xl text-white/62 max-w-xl mb-9 leading-relaxed font-light"
            id="hero-description"
          >
            InsetCarbon deploys Enhanced Rock Weathering across Indian agricultural supply chains, permanently sequestering carbon while rebuilding soil health for the farmers you depend on.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.44 }}
            className="flex flex-wrap gap-2 mb-10"
            id="hero-features-list"
          >
            {HERO_FEATURES.map((feat) => {
              const IconComp = feat.icon;
              return (
                <div
                  key={feat.label}
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-white/8 bg-white/[0.03] backdrop-blur-md transition-all duration-300 hover:bg-white/[0.06] hover:border-white/15 hover:scale-[1.02]"
                >
                  <IconComp className="w-3.5 h-3.5 shrink-0 text-[#3de3a6]/70" />
                  <span className="text-[11px] font-semibold whitespace-nowrap text-white/85">
                    {feat.label}
                  </span>
                </div>
              );
            })}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.54 }}
            className="flex flex-col sm:flex-row gap-3"
            id="hero-cta-buttons"
          >
            <a href="#corporates" id="hero-primary-cta">
              <button
                className="bg-[#122319]/80 text-white border border-[#3de3a6]/30 hover:bg-[#3de3a6]/10 hover:border-[#3de3a6]/60 px-7 py-3.5 rounded-full font-semibold text-sm transition-all duration-300 shadow-lg backdrop-blur-sm"
                id="hero-primary-cta-btn"
              >
                Design your insetting programme →
              </button>
            </a>
            <a href="#erw" id="hero-secondary-cta">
              <button
                className="bg-white/8 text-white px-7 py-3.5 rounded-full font-medium text-sm border border-white/14 hover:bg-white/12 transition-colors backdrop-blur-sm"
                id="hero-secondary-cta-btn"
              >
                How ERW works
              </button>
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7 }}
          className="mt-20 flex flex-wrap gap-x-12 gap-y-5"
          id="hero-stats-panel"
        >
          {HERO_STATS.map((stat) => (
            <div key={stat.label} className="flex flex-col">
              <span className="text-white font-semibold text-lg tracking-tight leading-tight">
                {stat.value}
              </span>
              <span className="text-white/40 text-xs font-mono uppercase tracking-wider mt-0.5">
                {stat.label}
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      <motion.div
        animate={{ y: [0, 7, 0] }}
        transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 pointer-events-none"
        id="hero-scroll-indicator"
      >
        <div className="w-px h-9 bg-gradient-to-b from-white/0 to-white/28" />
        <div className="w-1.5 h-1.5 rounded-full bg-white/28" />
      </motion.div>
    </section>
  );
}
