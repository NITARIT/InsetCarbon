import { motion } from "motion/react";
import { ProblemStat } from "../types";
import InteractiveZoomCard from "./InteractiveZoomCard";

const PROBLEM_STATS: ProblemStat[] = [
  { value: "70–90%", label: "of corporate emissions", sub: "are Scope 3" },
  {
    value: "<5%",
    label: "of Scope 3 is addressed",
    sub: "by existing carbon markets",
  },
  {
    value: "$1T+",
    label: "annual agricultural sourcing",
    sub: "exposed to climate risk",
  },
];

const INSETTING_POINTS = [
  "Scope 3 impact at the source",
  "Geographically linked to your procurement",
  "Verified by Isometric MRV",
  "Soil health and farmer resilience",
];

const OFFSETTING_POINTS = [
  "Moves climate action outside your own supply chain",
  "No direct impact on your sourcing farmers",
  "Limited traceability and operational visibility",
  "Higher regulatory and reputational risk",
  "No soil, yield, or livelihood benefits for your farmers",
];

export default function ProblemSection() {
  return (
    <section className="py-28 md:py-36 bg-site-bg" id="problem">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.65 }}
          className="max-w-3xl mb-16"
        >
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-5 font-semibold">
            The Scope 3 Problem
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-semibold text-forest tracking-tight leading-[1.08] mb-6">
            The carbon is already in{" "}
            <em className="not-italic text-brand">your supply chain.</em>
          </h2>
          <p className="text-base md:text-lg text-muted font-light leading-relaxed max-w-2xl">
            For food, beverage, and textile companies, agricultural Scope 3
            emissions represent the bulk of their climate footprint, and
            generic offsets purchased elsewhere do not fix them.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {PROBLEM_STATS.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="bg-white px-10 py-12 rounded-3xl hover:bg-brand/3 transition-colors duration-300"
            >
              <div className="text-4xl md:text-5xl font-semibold text-forest tracking-tight mb-2">
                {stat.value}
              </div>
              <div className="text-sm font-medium text-forest/80 mb-0.5">
                {stat.label}
              </div>
              <div className="text-xs text-muted font-mono tracking-wide">
                {stat.sub}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-5">
          <InteractiveZoomCard
            initial={{ opacity: 0, x: -16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
            className="bg-[#1A3C2B] rounded-3xl p-9 relative overflow-hidden"
            glowColor="rgba(29, 158, 117, 0.18)"
          >
            <div className="absolute top-0 right-0 w-48 h-48 bg-brand/10 blur-3xl rounded-full pointer-events-none animate-pulse" />
            <p className="text-[11px] font-mono text-brand/80 uppercase tracking-[0.18em] mb-3">
              Carbon Insetting
            </p>
            <h3 className="text-xl md:text-2xl font-semibold text-white mb-5 leading-snug">
              Removes CO₂{" "}
              <em className="not-italic text-brand">within</em> your supply
              chain, traceable to the exact farm.
            </h3>
            <ul className="space-y-2.5">
              {INSETTING_POINTS.map((pt) => (
                <li
                  key={pt}
                  className="flex items-start gap-2.5 text-sm text-white/70"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-brand mt-1.5 shrink-0" />
                  {pt}
                </li>
              ))}
            </ul>
          </InteractiveZoomCard>

          <InteractiveZoomCard
            initial={{ opacity: 0, x: 16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.07 }}
            className="bg-[#0F1F17] rounded-3xl p-9 border border-white/5"
            glowColor="rgba(255, 255, 255, 0.08)"
          >
            <p className="text-xs font-mono text-white/50 uppercase tracking-[0.2em] mb-3 font-semibold">
              Generic Offsets
            </p>
            <h3 className="text-xl md:text-2xl font-semibold text-white/75 mb-5 leading-snug">
              Displaces action to unrelated projects. Does not address your
              Scope 3 source.
            </h3>
            <ul className="space-y-2.5">
              {OFFSETTING_POINTS.map((pt) => (
                <li
                  key={pt}
                  className="flex items-start gap-2.5 text-sm text-white/70"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 mt-1.5 shrink-0" />
                  {pt}
                </li>
              ))}
            </ul>
          </InteractiveZoomCard>
        </div>
      </div>
    </section>
  );
}
