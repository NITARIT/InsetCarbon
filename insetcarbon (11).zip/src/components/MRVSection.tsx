import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Database, Pickaxe, MapPin, FlaskConical, ShieldCheck } from "lucide-react";
import { MRVStep } from "../types";

const MRV_STEPS: MRVStep[] = [
  {
    icon: Database,
    title: "Supply chain & baseline mapping",
    body: "We analyze your agricultural sourcing regions, establish soil geochemical baselines, identify basalt-suitable farm clusters, and confirm farmer onboarding for the programme.",
  },
  {
    icon: Pickaxe,
    title: "Basalt procurement & safety verification",
    body: "Certified basalt is sourced from local quarries. Mineral composition is analyzed and heavy metal thresholds verified against regulatory and Isometric standards before field use.",
  },
  {
    icon: MapPin,
    title: "Precision field deployment",
    body: "Agronomists manage calibrated application of milled basalt, collecting geolocated field records, application weights, and photographic evidence at every site.",
  },
  {
    icon: FlaskConical,
    title: "Longitudinal soil sampling",
    body: "Periodic soil, water, and biomass sampling tracks pH shift, bicarbonate formation, and crop response. Multi-season datasets build statistically robust removal estimates.",
  },
  {
    icon: ShieldCheck,
    title: "Third-party verification (Isometric)",
    body: "All field data, geochemical models, and MRV documentation are submitted to Isometric, one of the most rigorous verification standards for ERW carbon removal.",
  },
];

export default function MRVSection() {
  const [activeIdx, setActiveIdx] = useState<number | null>(0);

  return (
    <section className="py-24 md:py-32 bg-[#060c08] text-white relative" id="science">
      {/* No background grid pattern */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14"
        >
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-4 font-semibold">
            MRV Process
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight leading-[1.08] max-w-3xl">
            Verified from quarry to supply chain by Isometric.
          </h2>
          <p className="mt-5 text-base text-white/45 font-light leading-relaxed max-w-2xl">
            Every tonne of carbon removal we claim is backed by field-level
            evidence, independent laboratory analysis, and third-party
            verification.
          </p>
        </motion.div>

        <div className="flex flex-col gap-2 max-w-4xl">
          {MRV_STEPS.map((step, idx) => {
            const IconComp = step.icon;
            const isOpen = activeIdx === idx;
            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.07 }}
                className={`border rounded-2xl cursor-pointer overflow-hidden transition-colors duration-200 ${
                  isOpen
                    ? "border-brand/35 bg-white/4"
                    : "border-white/6 bg-white/2 hover:border-white/15"
                }`}
                onClick={() => setActiveIdx(isOpen ? null : idx)}
              >
                <div className="flex items-center gap-4 p-5 md:p-6 select-none">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                      isOpen
                        ? "bg-brand/20 border border-brand/30"
                        : "bg-white/5 border border-white/8"
                    }`}
                  >
                    <IconComp
                      className={`w-4 h-4 ${isOpen ? "text-brand" : "text-white/45"}`}
                    />
                  </div>
                  <span className="text-2xl font-bold text-white/12 font-mono w-6 shrink-0">
                    {String(idx + 1).padStart(2, "0")}
                  </span>
                  <h4
                    className={`flex-1 text-sm md:text-base font-semibold transition-colors ${
                      isOpen ? "text-white" : "text-white/70"
                    }`}
                  >
                    {step.title}
                  </h4>
                  <span
                    className={`text-lg font-light shrink-0 transition-colors ${
                      isOpen ? "text-brand" : "text-white/30"
                    }`}
                  >
                    {isOpen ? "−" : "+"}
                  </span>
                </div>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.22 }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 md:px-6 pb-5 md:pb-6 md:pl-[5.5rem] text-sm text-white/55 leading-relaxed font-light">
                        {step.body}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.25 }}
          className="mt-10 inline-flex items-center gap-3 border border-brand/25 bg-brand/8 rounded-full px-5 py-2.5"
        >
          <ShieldCheck className="w-4 h-4 text-brand" />
          <span className="text-sm font-medium text-white/70">
            Verified by <strong className="text-white font-semibold">Isometric</strong>, the highest-rigour ERW standard
          </span>
        </motion.div>
      </div>
    </section>
  );
}
