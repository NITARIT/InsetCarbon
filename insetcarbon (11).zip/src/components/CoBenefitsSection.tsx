import { motion } from "motion/react";
import {
  HeartPulse,
  Droplet,
  Sprout,
  Leaf,
  Coins,
  Sun,
  Shield,
  Layers,
} from "lucide-react";
import { CoBenefitItem } from "../types";

const CO_BENEFITS: CoBenefitItem[] = [
  {
    icon: HeartPulse,
    label: "Soil health improvement",
    desc: "Basalt helps reduce soil acidity and improves nutrient availability for crops.",
    color: "text-brand",
  },
  {
    icon: Droplet,
    label: "Better water retention",
    desc: "Improved soil structure helps fields retain moisture during dry periods.",
    color: "text-blue-400",
  },
  {
    icon: Leaf,
    label: "Natural mineral nutrition",
    desc: "Releases calcium, magnesium, potassium, and silica naturally into the soil.",
    color: "text-emerald-400",
  },
  {
    icon: Coins,
    label: "Lower farming costs",
    desc: "Reduces dependence on chemical lime and some synthetic fertilizers.",
    color: "text-lime-500",
  },
  {
    icon: Sprout,
    label: "Higher crop productivity",
    desc: "Healthier soils can support better yields and improved crop quality.",
    color: "text-amber-500",
  },
  {
    icon: Sun,
    label: "Farmer's Livelihood Growth",
    desc: "Improving soil health, lowering farming costs, and creating stronger long-term incomes through regenerative carbon removal",
    color: "text-orange-400",
  },
  {
    icon: Shield,
    label: "Climate resilience",
    desc: "Supports farmers against irregular rainfall, heat stress, and degraded soils.",
    color: "text-purple-400",
  },
  {
    icon: Layers,
    label: "Durable carbon removal",
    desc: "Enhanced Rock Weathering stores carbon for 1,000+ years with science-backed MRV.",
    color: "text-sky-400",
  },
];

export default function CoBenefitsSection() {
  return (
    <section className="py-24 md:py-32 bg-site-bg">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14"
        >
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-4 font-semibold">
            Co-Benefits
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-semibold text-forest tracking-tight leading-[1.08] max-w-2xl">
            Carbon removal that strengthens farmers, soil, and supply chains.
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {CO_BENEFITS.map((benefit, idx) => {
            const IconComp = benefit.icon;
            return (
              <motion.div
                key={benefit.label}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.07 }}
                whileHover={{ y: -4, transition: { duration: 0.2 } }}
                className="bg-white rounded-2xl p-7 border border-forest/6 hover:border-brand/30 hover:shadow-[0_4px_24px_rgba(29,158,117,0.08)] transition-all duration-300"
              >
                <IconComp className={`w-5 h-5 ${benefit.color} mb-5`} />
                <h4 className="text-sm font-semibold text-forest mb-2">
                  {benefit.label}
                </h4>
                <p className="text-xs text-muted leading-relaxed">
                  {benefit.desc}
                </p>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-10 bg-[#1A3C2B] rounded-3xl px-10 py-8 flex justify-center"
        >
          <p className="text-white/80 text-base md:text-lg font-light leading-relaxed italic text-center max-w-3xl">
            <span className="text-brand text-2xl md:text-3xl font-serif mr-1 select-none leading-none">&ldquo;</span>
            (When you inset ERW into your supply chain, you're not just buying carbon credits, you're co-investing in the agricultural resilience of the communities your business depends on.)
            <span className="text-brand text-2xl md:text-3xl font-serif ml-1 select-none leading-none">&rdquo;</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
