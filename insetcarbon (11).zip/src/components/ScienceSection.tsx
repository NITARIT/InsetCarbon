import { motion } from "motion/react";
import { CloudRain, Pickaxe, Waves } from "lucide-react";
import { WeatheringStep } from "../types";

const WEATHERING_STEPS: WeatheringStep[] = [
  {
    num: "01",
    icon: CloudRain,
    label: "CO₂ Dissolves",
    formula: "CO₂ + H₂O → H₂CO₃",
    desc: "Atmospheric CO₂ dissolves in rainwater, forming carbonic acid.",
    accent: "rgba(96,165,250,0.8)",
    ring: "border-blue-400/25",
    bg: "from-blue-500/15 to-blue-400/3",
    iconCls: "text-blue-300",
  },
  {
    num: "02",
    icon: Pickaxe,
    label: "Basalt Applied",
    formula: "Milled silicate rock",
    desc: "Finely milled basalt is spread across agricultural fields, massively increasing reactive surface area.",
    accent: "rgba(29,158,117,0.9)",
    ring: "border-brand/30",
    bg: "from-brand/20 to-brand/3",
    iconCls: "text-brand",
  },
  {
    num: "03",
    icon: () => (
      <span className="text-[15px] font-bold font-mono text-amber-600 tracking-tight">
        HCO₃⁻
      </span>
    ),
    label: "Carbon Bound",
    formula: "Weathering reaction",
    desc: "Carbonic acid reacts with silicate minerals, binding CO₂ as stable bicarbonate ions.",
    accent: "rgba(217,119,6,0.8)",
    ring: "border-amber-600/30",
    bg: "from-amber-600/20 to-amber-600/3",
    iconCls: "text-amber-600",
  },
  {
    num: "04",
    icon: Waves,
    label: "Permanent Storage",
    formula: "10,000+ yr stability",
    desc: "Bicarbonates flow into rivers and oceans, geologically stable for tens of thousands of years.",
    accent: "rgba(34,211,238,0.8)",
    ring: "border-cyan-400/25",
    bg: "from-cyan-500/15 to-cyan-400/3",
    iconCls: "text-cyan-300",
  },
];

interface ParticleProps {
  delay: number;
}

function Particle({ delay }: ParticleProps) {
  return (
    <motion.div
      className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white"
      style={{
        boxShadow:
          "0 0 14px 6px rgba(29,158,117,0.9), 0 0 30px 12px rgba(20,184,166,0.45)",
        left: 0,
      }}
      animate={{ left: ["0%", "100%"] }}
      transition={{ duration: 10, delay, repeat: Infinity, ease: "linear" }}
    />
  );
}

export default function ScienceSection() {
  return (
    <section className="bg-[#070f09] text-white overflow-hidden" id="erw">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-24 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-5 font-semibold">
            The Science
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight leading-[1.08] max-w-xl mx-auto mb-5">
            Accelerating Earth's
            <br />
            natural carbon cycle.
          </h2>
          <p className="text-base md:text-lg text-white/50 font-light max-w-2xl mx-auto leading-relaxed">
            Rock weathering has regulated Earth's climate for 4 billion years.
            ERW compresses that timescale from millennia to decades.
          </p>
        </motion.div>
      </div>

      <div className="w-full px-4 sm:px-8 lg:px-16 pb-24">
        <div className="relative bg-white/3 border border-white/6 rounded-[2rem] p-8 md:p-12 lg:p-16 overflow-hidden">
          {/* No background grid pattern */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-px bg-gradient-to-r from-transparent via-brand/60 to-transparent" />

          {/* Desktop Steps */}
          <div className="hidden md:block">
            <div className="relative flex items-start justify-between">
              {/* Invisible path for the looping particle */}
              <div className="absolute left-[44px] right-[44px] top-[43px] h-[3px] overflow-visible z-0 pointer-events-none">
                <Particle delay={0} />
              </div>

              {WEATHERING_STEPS.map((step, idx) => {
                const IconComp = step.icon;
                return (
                  <motion.div
                    key={step.label}
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: idx * 0.1 }}
                    whileHover={{ y: -6, transition: { duration: 0.25 } }}
                    className="relative z-10 flex flex-col items-center text-center flex-1"
                  >
                    <div
                      className={`w-[88px] h-[88px] rounded-full bg-gradient-to-br ${step.bg} border ${step.ring} flex items-center justify-center mb-7 relative`}
                      style={{
                        boxShadow: `0 0 32px ${step.accent}25`,
                      }}
                    >
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{
                          repeat: Infinity,
                          duration: 16,
                          ease: "linear",
                        }}
                        className={`absolute -inset-2.5 rounded-full border border-dashed ${step.ring} opacity-30`}
                      />

                      <span className={`relative z-10 ${step.iconCls}`}>
                        {typeof IconComp === "function" &&
                        IconComp.length === 0 ? (
                          <IconComp />
                        ) : (
                          <IconComp className="w-8 h-8" />
                        )}
                      </span>
                    </div>

                    <p className="text-[10px] font-mono text-white/25 tracking-[0.18em] uppercase mb-2">
                      {step.num}
                    </p>
                    <h4 className="text-sm md:text-base font-semibold text-white mb-2">
                      {step.label}
                    </h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-white/45 mb-3 block">
                      {step.formula}
                    </span>
                    <p className="text-xs text-white/45 leading-relaxed max-w-[9.5rem]">
                      {step.desc}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Mobile Steps */}
          <div className="md:hidden flex flex-col gap-8 relative">
            {/* Invisible path for mobile looping particle */}
            <div className="absolute left-[26px] top-6 bottom-6 w-1 overflow-visible z-0 pointer-events-none">
              <motion.div
                className="absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-white"
                style={{
                  boxShadow: "0 0 14px 6px rgba(29,158,117,0.9), 0 0 30px 12px rgba(20,184,166,0.45)",
                  top: 0,
                }}
                animate={{ top: ["0%", "100%"] }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              />
            </div>

            {WEATHERING_STEPS.map((step, idx) => {
              const IconComp = step.icon;
              return (
                <motion.div
                  key={step.label}
                  initial={{ opacity: 0, x: -12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.09 }}
                  className="relative z-10 flex items-start gap-5"
                >
                  <div
                    className={`w-[52px] h-[52px] shrink-0 rounded-full bg-gradient-to-br ${step.bg} border ${step.ring} flex items-center justify-center`}
                    style={{
                      boxShadow: `0 0 20px ${step.accent}20`,
                    }}
                  >
                    <span className={step.iconCls}>
                      {typeof IconComp === "function" &&
                      IconComp.length === 0 ? (
                        <IconComp />
                      ) : (
                        <IconComp className="w-5 h-5" />
                      )}
                    </span>
                  </div>

                  <div className="pt-1">
                    <p className="text-[10px] font-mono text-white/30 tracking-wider uppercase mb-0.5">
                      {step.num}
                    </p>
                    <h4 className="text-sm font-semibold text-white mb-1">
                      {step.label}
                    </h4>
                    <p className="text-xs text-white/45 leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-6 bg-white/3 border border-white/6 rounded-3xl p-8 md:p-10"
        >
          <div className="grid md:grid-cols-[160px_1fr] gap-6 md:gap-10 items-start">
            <p className="text-[11px] font-mono text-brand uppercase tracking-[0.18em] font-semibold pt-1">
              The Chemistry
            </p>
            <p className="text-sm md:text-base text-white/55 leading-relaxed font-light">
              When carbonic acid contacts silicate minerals in basalt, it
              triggers a dissolution reaction. Silicon, calcium, and magnesium
              cations enter solution while CO₂ is converted to bicarbonate
              (HCO₃⁻), a form that is chemically stable in the ocean for
              geological timescales. This is not sequestration by organisms or
              soils that can reverse; it is inorganic geochemical capture.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
