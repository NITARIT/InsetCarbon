import { motion } from "motion/react";

interface LogoProps {
  variant?: "light" | "dark";
  heightClass?: string;
  className?: string;
}

export default function Logo({
  variant = 'light',
  heightClass = "h-[32px] md:h-[38px]",
  className = "",
}: LogoProps) {
  // Map height to responsive text bounds for consistent, beautifully proportioned layout
  const textClass = heightClass.includes("h-6") 
    ? "text-[21px] md:text-[23px]" 
    : heightClass.includes("h-5") 
    ? "text-[17px] md:text-[19px]" 
    : "text-[24px] md:text-[28px]";

  // The website's primary dark color is forest green (#1A3C2B), light text color is white.
  // We use the brand green (#1D9E75) as a beautiful accent color on the hexagonal carbon symbol.
  const textColorClass = variant === "dark" ? "text-white" : "text-forest";
  const brandColorClass = variant === "dark" ? "text-[#8db9a1]" : "text-brand";

  return (
    <motion.a
      href="#"
      aria-label="InsetCarbon"
      className={`shrink-0 flex items-center select-none cursor-pointer ${className} ${heightClass}`}
      style={{ textDecoration: "none" }}
      whileHover="hovered"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className={`flex items-center font-sans font-semibold tracking-[-0.035em] ${textClass} ${textColorClass}`}>
        <span>InsetCarb</span>
        
        {/* Hexagonal Carbon group 'o' - Structured with perfect custom side-car spacing */}
        <motion.span
          className={`inline-flex items-center justify-center ml-[0.14em] mr-[0.11em] select-none ${brandColorClass}`}
          variants={{
            hovered: { scale: 1.08 },
          }}
          transition={{ type: "spring", stiffness: 400, damping: 10 }}
        >
          <svg
            viewBox="0 0 26 22"
            className="h-[0.74em] w-auto fill-none"
            style={{ display: "inline-block", verticalAlign: "middle", marginTop: "-0.04em" }}
            stroke="currentColor"
            strokeWidth="3.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {/* Hexagonal Open C-Structure representing Carbon 'O' */}
            <path
              d="M 17.8 6.5 L 14.8 3.2 L 7.5 3.2 L 2.8 11.0 L 7.5 18.8 L 14.8 18.8 L 17.8 15.5"
            />
            {/* Molecular Particles nested on the right side of the 'C' structure */}
            <circle cx="21.5" cy="6.6" r="2.6" fill="currentColor" stroke="none" />
            <circle cx="17.2" cy="11.0" r="2.9" fill="currentColor" stroke="none" />
            <circle cx="21.2" cy="15.8" r="2.1" fill="currentColor" stroke="none" />
          </svg>
        </motion.span>

        <span>n</span>
      </div>
    </motion.a>
  );
}
