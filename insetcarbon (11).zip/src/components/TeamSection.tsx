import { motion } from "motion/react";
import { Globe, Tractor, FlaskConical, TrendingUp, BookOpen, ShieldCheck } from "lucide-react";
import { FeatureCard } from "../types";

const TEAM_CARDS: FeatureCard[] = [
  {
    icon: Globe,
    title: "Geospatial Intelligence",
    desc: "Smart mapping systems that combine weather, soil, and farm locations to find the best local regions for soil-mineral application.",
    metrics: [
      "Regional soil mapping",
      "Local weather history",
      "Cropland analysis",
      "Farming region priority",
    ],
    accent: "#1D9E75",
  },
  {
    icon: Tractor,
    title: "Field Operations & Deployment",
    desc: "Years of hands-on work applying rock minerals to fields. We coordinate transport, work with local stone crushers, and partner directly with farmers on the ground.",
    metrics: [
      "Farm-level execution",
      "Basalt transport networks",
      "Local farmer partnerships",
      "On-the-ground management",
    ],
    accent: "#10b981",
  },
  {
    icon: FlaskConical,
    title: "Carbon Science & MRV",
    desc: "Rigorous soil testing and water sampling to measure carbon storage. We track actual soil mineral changes in independent labs to verify captured carbon.",
    metrics: [
      "Certified carbon tracking",
      "Detailed soil lab analysis",
      "Conservative accounting",
      "Multi-year monitoring",
    ],
    accent: "#38bdf8",
  },
  {
    icon: TrendingUp,
    title: "Carbon Finance & Insetting",
    desc: "Helping agricultural and food brands map carbon savings to their supply chains. We design transparent insetting frameworks supporting corporate net-zero goals.",
    metrics: [
      "Supply chain insets",
      "Auditable carbon credits",
      "Custom programs",
      "Transparent cost structures",
    ],
    accent: "#d97706",
  },
  {
    icon: BookOpen,
    title: "IIT Backed Science",
    desc: "Partnering with leading research centers, IIT-linked ecosystems, and agricultural universities. Every action we take is backed by peer-reviewed science.",
    metrics: [
      "IIT-linked ecosystems",
      "University validations",
      "Peer-reviewed methods",
      "Continuous data tracking",
    ],
    accent: "#a78bfa",
  },
];

const TICKER_ITEMS = [
  "Operational since 2022",
  "Smart GIS mapping",
  "Science-backed soil testing",
  "Carbon supply-chain finance",
  "Real farming deployment",
  "Certified soil verification",
];

interface CardProps {
  card: FeatureCard;
  delay: number;
  key?: string;
}

function TeamCard({ card, delay }: CardProps) {
  const IconComp = card.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className="group flex flex-col justify-between h-full bg-white/[0.04] border border-white/[0.07] rounded-xl p-5 relative overflow-hidden hover:border-brand/30 hover:bg-white/[0.06] transition-all duration-300 hover:shadow-[0_0_40px_rgba(29,158,117,0.08)]"
    >
      <div
        className="absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `radial-gradient(circle, ${card.accent}30 0%, transparent 70%)`,
        }}
      />
      <div>
        <div className="w-9 h-9 rounded-lg bg-white/[0.06] border border-white/[0.08] flex items-center justify-center mb-3 group-hover:border-brand/25 transition-colors">
          <IconComp className="w-4 h-4" style={{ color: card.accent }} />
        </div>
        <h3 className="text-sm font-semibold text-white mb-1.5">{card.title}</h3>
        <p className="text-xs text-white/50 leading-relaxed mb-4 font-light">
          {card.desc}
        </p>
      </div>
      <div className="pt-3 border-t border-white/[0.06] grid grid-cols-2 gap-y-1.5 gap-x-3 mt-auto">
        {card.metrics.map((metric) => (
          <div
            key={metric}
            className="flex items-center gap-1.5 text-[10px] text-white/40"
          >
            <span
              className="w-1 h-1 rounded-full shrink-0"
              style={{ background: card.accent }}
            />
            {metric}
          </div>
        ))}
      </div>
    </motion.div>
  );
}

export default function TeamSection() {
  return (
    <section
      className="py-24 md:py-32 bg-[#12241b] text-white overflow-hidden relative"
      id="team"
    >
      {/* Cinematic, luxury background reflection element with increased visibility */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none opacity-[0.30]">
        <img
          src="https://drive.google.com/thumbnail?id=1kqE0KmZI6Xbe1Y92h2EQMqzMbOj-jEhj&sz=w1600"
          alt="Atmospheric reflection texture"
          loading="lazy"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover select-none pointer-events-none mix-blend-screen"
          style={{
            filter: "blur(1.5px) saturate(1.35) brightness(0.48) contrast(1.1)",
            objectPosition: "50% 50%",
          }}
        />
        {/* Soft professional gradient overlays to prevent harsh edges and blend completely */}
        <div className="absolute inset-x-0 top-0 h-1/5 bg-gradient-to-b from-[#12241b] to-transparent" />
        <div className="absolute inset-x-0 bottom-0 h-1/5 bg-gradient-to-t from-[#12241b] to-transparent" />
        <div className="absolute inset-y-0 left-0 w-1/5 bg-gradient-to-r from-[#12241b] to-transparent" />
        <div className="absolute inset-y-0 right-0 w-1/5 bg-gradient-to-l from-[#12241b] to-transparent" />
        
        {/* Soft emerald and teal tint overlays */}
        <div 
          className="absolute inset-0 bg-[#1D9E75] mix-blend-color opacity-[0.15]"
        />
        
        {/* Luxury dynamic bloom lighting */}
        <div 
          className="absolute inset-0 mix-blend-color-dodge opacity-[0.22]"
          style={{
            background: "radial-gradient(circle at 50% 40%, rgba(61, 227, 166, 0.2) 0%, transparent 70%)"
          }}
        />
      </div>

      {/* Luxury light glow accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-[#3de3a6]/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14"
        >
          <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-4 font-semibold">
            Our Team
          </p>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight leading-[1.1] max-w-3xl mb-5">
            Built by operators, geospatial experts, and carbon practitioners
            working on ERW since 2022.
          </h2>
          <p className="text-base text-white/50 font-light leading-relaxed max-w-2xl">
            InsetCarbon combines field operations, GIS intelligence, carbon
            science, and deployment capability to build scalable carbon
            insetting systems across agricultural supply chains.
          </p>
        </motion.div>

        {/* First Row: 3 Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          {TEAM_CARDS.slice(0, 3).map((card, idx) => (
            <TeamCard key={card.title} card={card} delay={idx * 0.09} />
          ))}
        </div>

        {/* Second Row: 2 Cards centered */}
        <div className="grid sm:grid-cols-2 gap-4 lg:grid-cols-2 lg:max-w-[calc(66.666%+8px)] mx-auto mb-10">
          {TEAM_CARDS.slice(3).map((card, idx) => (
            <TeamCard key={card.title} card={card} delay={(idx + 3) * 0.09} />
          ))}
        </div>

        {/* Science and Research Box */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-white/[0.04] border border-white/[0.08] rounded-3xl p-8 md:p-10 mb-8"
        >
          <div className="grid md:grid-cols-2 gap-8 items-start">
            <div>
              <p className="text-xs sm:text-sm font-mono text-brand uppercase tracking-[0.22em] mb-3 font-semibold">
                Science-Backed Approach
              </p>
              <h3 className="text-xl md:text-2xl font-semibold mb-4 leading-snug">
                Built on field validation and advanced ERW methodologies.
              </h3>
              <p className="text-sm text-white/55 leading-relaxed font-light">
                Our approach combines GIS satellite mapping, hands-on field sampling, deep laboratory soil analysis, and logistics. This guarantees that carbon tracking is grounded in physical measurements rather than theory, and validated.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {[
                "Science-backed soil frameworks",
                "Respected research partnerships",
                "Transparent carbon accounting",
                "Independent laboratory testing",
                "Long-term soil health monitoring",
                "Conservative, verified metrics",
                "Continuous mineral tracking",
                "Smart geographical mapping",
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-2 text-xs text-white/55 leading-snug animate-fadeIn"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-brand/80 mt-1.5 shrink-0" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Infinite Running Ticker Tape */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="relative overflow-hidden rounded-2xl border border-white/[0.06] bg-white/[0.02] py-3.5"
        >
          <div className="flex animate-[scroll_20s_linear_infinite] whitespace-nowrap">
            {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-3 mx-6 text-[11px] font-mono text-white/40 uppercase tracking-widest shrink-0"
              >
                <span className="w-1 h-1 rounded-full bg-brand/60" />
                {item}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
export { TeamCard };
export type { FeatureCard };
