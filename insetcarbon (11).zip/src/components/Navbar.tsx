import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Linkedin, Menu, X } from "lucide-react";
import Logo from "./Logo";
import { NavigationItem } from "../types";

const NAV_LINKS: NavigationItem[] = [
  { label: "How It Works", href: "#erw" },
  { label: "Science & MRV", href: "#science" },
  { label: "For Corporates", href: "#corporates" },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 24);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <motion.nav
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-site-bg/96 backdrop-blur-xl shadow-sm border-b border-forest/8"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 md:h-[72px] flex items-center justify-between">
          <Logo variant="light" heightClass="h-6 md:h-[26px]" />

          <div className="hidden md:flex items-center gap-7 text-[13px] font-medium text-forest/70">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-forest transition-colors"
                id={`nav-link-${link.label.replace(/\s+/g, "").toLowerCase()}`}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <a
              href="https://www.linkedin.com/company/insetcarbon/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-forest/40 hover:text-forest transition-colors p-1.5"
              id="nav-linkedin-button"
            >
              <Linkedin size={15} />
            </a>
            <a href="#contact" id="nav-desktop-contact-button">
              <button
                className="bg-forest text-site-bg px-5 py-2 rounded-full text-[13px] font-semibold hover:bg-brand transition-colors duration-200"
                id="nav-desktop-contact-inner"
              >
                Get in touch
              </button>
            </a>
          </div>

          <button
            className="md:hidden p-2 text-forest"
            onClick={() => setIsOpen((prev) => !prev)}
            aria-label="Menu"
            id="nav-mobile-toggle"
          >
            {isOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </motion.nav>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm md:hidden"
              onClick={() => setIsOpen(false)}
              id="nav-mobile-overlay"
            />
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
              className="fixed top-16 left-0 right-0 z-50 md:hidden bg-site-bg border-b border-forest/8 shadow-lg"
              id="nav-mobile-menu"
            >
              <div className="px-6 py-5 flex flex-col gap-4">
                {NAV_LINKS.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="text-sm font-medium text-forest/80 py-2 border-b border-forest/5 last:border-0"
                    id={`mobile-link-${link.label.replace(/\s+/g, "").toLowerCase()}`}
                  >
                    {link.label}
                  </a>
                ))}
                <a
                  href="#contact"
                  onClick={() => setIsOpen(false)}
                  id="nav-mobile-contact-button-wrapper"
                >
                  <button
                    className="w-full mt-1 bg-forest text-site-bg px-5 py-3 rounded-full text-sm font-semibold"
                    id="nav-mobile-contact-inner"
                  >
                    Get in touch
                  </button>
                </a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
