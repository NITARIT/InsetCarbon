# Claude Optimization Guide (`claude.md`)

This file is optimized to help **Claude Code** and other AI-assisted IDE tools comprehend the codebase conventions, design structure, and integration specifications of **InsetCarbon** instantaneously.

---

## 🏗️ Architectural Context

* **Tailwind v4.0 Custom Theme Configs**: 
  Tailwind variables are declared directly in `@theme` block inside `/src/index.css`. Keep these in mind when extending components:
  * `--color-forest`: `#1a3c2b` (Deep primary aesthetic)
  * `--color-brand`: `#1d9e75` (Vibrant accent & highlight actions)
  * `--color-amber`: `#d97706` (Warning indicators, secondary metrics)
  * `--color-basalt`: `#111` (Mineral tones and dark contrast segments)
  * `--color-site-bg`: `#f7f6f2` (Light rustic slate-farm visual tone)
  * `--color-muted`: `#6a7063` (Helpful descriptive labels)

* **Typography Guidelines**:
  * Sans-Serif Body/Header: `"Inter"` (loaded from Google Fonts in `src/index.css`)
  * Monospaced Details: `"JetBrains Mono"` (applied to formulas, codes, metric statistics)

---

## 🧩 Component & Feature Map

When Claude Code is editing particular functional features, target these files:

1. **Brand Headers/Navigations**:
   * File: `/src/components/Navbar.tsx` & `/src/components/Logo.tsx`
   * Target: Smooth page anchors, menu states, responsive burger icon toggle.

2. **Technical Details of Enhanced Rock Weathering (ERW)**:
   * File: `/src/components/ScienceSection.tsx`
   * Target: Update equations (mineral carbonation chemistry, $CO_2$ dissolution) or interactive steps representing rock crushing, moisture application, and bicarbonate runoff.

3. **Geographical Data & Interactive Maps**:
   * File: `/src/components/MapSection.tsx`
   * Target: This component contains an interactive US map with custom path nodes. To append state logic or change basalt/logistic tiers, edit the `statesData` array directly inside `MapSection.tsx` matching `StateSuitability` structural types of `/src/types.ts`.

4. **Measurement, Reporting, and Verification (MRV)**:
   * File: `/src/components/MRVSection.tsx`
   * Target: Methods on geochemical auditing, isotopic tracking, and third-party validation processes.

5. **Contact Form / Lead Generation Entry**:
   * File: `/src/components/ContactSection.tsx`
   * Target: Capturing carbon-accounting buyer inquiries, form validation, and successful inquiry responses.

---

## 🎨 Best Practices & Standards for AI Edits

When generating additions or editing files, Claude Code MUST adhere to:

* **Modularity Rules**: Define all complex interfaces and lists in TypeScript in `/src/types.ts`. Do not write multi-line inline interfaces or type casting directly inside components.
* **Imports Hierarchy**: Named imports from standard packages first (e.g. `import { useState, useEffect } from "react";`), followed by types (e.g. `import { NavigationItem } from "../types";`), and then assets/subcomponents.
* **Component Splitting**: Avoid single files expanding above 400 lines. If a section expands (e.g. detailed statistics of Carbon Insets), break it down into smaller sub-components in the `/src/components/` directory.
* **Lucide Icon Integration**: Never build custom SVG icons. Select a fitting component directly from `lucide-react` and reference it directly. Example:
  ```tsx
  import { Shield, Sparkles, Scale } from "lucide-react";
  ```
* **Motion Choreography**: Always import motion components from `motion/react` rather than legacy packages. Maintain slight duration curves (`duration: 0.3` to `duration: 0.5`) with ease-in-out behaviors for rich premium web interactions.
