# InsetCarbon

**Permanent Supply Chain Decarbonization via Enhanced Rock Weathering (ERW)**

InsetCarbon is a highly polished, interactive web application showcasing a pioneer in permanent carbon removal. It facilitates Scope 3 supply chain decarbonization by deploying Enhanced Rock Weathering (ERW) across agricultural lands.

---

## 🚀 Key Features

* **Advanced Science Section**: Interactive chemical equations and physical processes backing Enhanced Rock Weathering (ERW) using basalt dust.
* **Geographical Suitability Map**: Dynamic SVG-based interactive US map demonstrating local suitability (basalt availability, farm proximity, and carbon potential).
* **Measurement, Reporting & Verification (MRV)**: Outline of rigorous geochemical, isotopic, and modeling verification methods.
* **Agronomic Co-Benefits Display**: Explains how ERW neutralizes soil acidity, provides micronutrients, and improves crop yields.
* **Corporate Integration Workflow**: Designed specifically for enterprise supply chain grain buyers to inset Scope 3 emissions securely.

---

## 🛠️ Technology Stack

* **UI Library**: React 19
* **Language**: TypeScript
* **State Management**: React Hooks (dynamic US map interaction, modal states, inquiries)
* **Design & Styling**: Tailwind CSS v4.0 for utility-first styling and robust custom designs
* **Animations**: motion (from `motion/react`) for graceful micro-interactions and scrolls
* **Iconography**: Lucide React
* **Build System**: Vite 6 (configured for lightning-fast bundling, single port mapping, and live preview)

---

## 📂 Project Structure

```text
├── .env.example            # Environment configurations (Gemini and deployment settings)
├── .gitignore              # Files git should ignore
├── README.md               # Home documentation for developers/investors
├── claude.md               # Optimization documentation for AI/Claude Code workflow
├── startup_instructions.md  # Step-by-step application instantiation guidelines
├── index.html              # Custom index entry point (pre-matched meta title)
├── package.json            # Active metadata, scripts, and preselected dependencies
├── tsconfig.json           # Strictly typed and resolved typescript configs
├── vite.config.ts          # Port 3000 reverse-proxy binding with HMR optimization
└── src/
    ├── App.tsx             # Central layout controller invoking modular segments
    ├── index.css           # Modern Inter and JetBrains Mono fonts and Tailwind directives
    ├── main.tsx            # DOM hook injector
    ├── types.ts            # Highly organized, reusable TypeScript data models
    └── components/
        ├── Navbar.tsx             # Interactive header with menu scroll transitions
        ├── HeroSection.tsx        # Dynamic banner on agricultural decarbonization
        ├── ProblemSection.tsx     # Supply chain Scope 3 emission visualizations
        ├── ScienceSection.tsx     # Enhanced rock weathering chemistry mechanics
        ├── CoBenefitsSection.tsx  # Interactive displays on soil & crop performance
        ├── MapSection.tsx         # Interactive SVG US Suitability map & detailed insights
        └── ...                    # Fully modular sections (Operations, MRV, Team, Contact)
```

---

## ⚡ Quick Start

### 1. Installation
Install project dependencies:
```bash
npm install
```

### 2. Run the Development Server
Launch the application locally or within the AI Studio active preview frame:
```bash
npm run dev
```
The app will bind directly to `http://localhost:3000` (and broadcast on `0.0.0.0`).

### 3. Production Build
Export static minimized files ready for production deployment:
```bash
npm run build
```

---

## 🧪 Compliance and Architecture

* **HMR Performance**: Configured to respect container environments, keeping file watching light to optimize CPU and RAM performance.
* **Vite Integration**: Bound to port `3000` which aligns perfectly with proxy networking systems without configuration errors.
